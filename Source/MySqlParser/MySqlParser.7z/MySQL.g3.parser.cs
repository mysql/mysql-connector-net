﻿namespace MySqlParser
{
	partial class MySQLParser
	{
	}
}
