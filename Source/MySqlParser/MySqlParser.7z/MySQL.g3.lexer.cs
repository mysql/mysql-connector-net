﻿namespace MySqlParser
{
	partial class MySQLLexer
	{
	}
}
