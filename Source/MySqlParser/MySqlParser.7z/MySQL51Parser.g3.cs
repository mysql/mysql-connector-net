﻿namespace MySqlParser
{
	partial class MySQL51Parser
	{
	}
}
